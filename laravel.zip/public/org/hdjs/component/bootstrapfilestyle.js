define(['package/bootstrap-filestyle.min'], function ($) {
    return function (el) {
        return $(el).filestyle();
    }
})